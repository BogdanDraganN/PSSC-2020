﻿--LOGIN needs to exist of the server first
CREATE USER [Provisioning]
	FOR LOGIN [Provisioning]

GO
GRANT CONNECT TO [Provisioning]

GO
