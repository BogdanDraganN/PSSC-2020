﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Access.Primitives.Extensions.Cloning
{
    public interface IDynClonable
    {
        object Clone();
    }
}
