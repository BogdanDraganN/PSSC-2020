﻿cd $PSScriptRoot

Start-Process ".\Samples\StackUnderflow.Bots\bin\Debug\netcoreapp3.1\StackUnderflow.Bots.exe"